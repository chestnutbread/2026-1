
# jet_engine.py
"""
Python reimplementation of the JetEng MATLAB turbojet engine model.

Original MATLAB code:
    (c) 2013, Rakesh Mandal, BSD-2-Clause license.
This Python translation is a derivative work; keep the original copyright
and license notice if you redistribute this file.
"""

from math import sqrt


def inlet(m1, T1, p1, PR, eff, gamma):
    """
    InletFunction.m

    Parameters
    ----------
    m1 : float
        Mass flow at inlet [kg/s]
    T1 : float
        Total temperature at inlet [K]
    p1 : float
        Total pressure at inlet [Pa]
    PR : float
        Inlet pressure ratio p2/p1 [-]
    eff : float
        Inlet isentropic efficiency [-]
    gamma : float
        Specific heat ratio for air [-]

    Returns
    -------
    m2, T2, p2 : floats
        Mass flow, temperature, pressure at inlet exit.
    """
    p2 = PR * p1
    # T2 = T1 * (1 - eff * (1 - (p2/p1)^((gamma-1)/gamma)))
    T2 = T1 * (1.0 - eff * (1.0 - (p2 / p1) ** ((gamma - 1.0) / gamma)))
    m2 = m1
    return m2, T2, p2


def compressor(m1, T1, p1, PR, eff, gamma, cp_air):
    """
    CompressorFunction.m

    Parameters
    ----------
    m1 : float
        Mass flow at compressor inlet [kg/s]
    T1 : float
        Total temperature at compressor inlet [K]
    p1 : float
        Total pressure at compressor inlet [Pa]
    PR : float
        Compressor pressure ratio p2/p1 [-]
    eff : float
        Isentropic efficiency [-]
    gamma : float
        Specific heat ratio for air [-]
    cp_air : float
        Cp of air [J/(kg*K)]

    Returns
    -------
    m2, T2, p2, W : floats
        Mass flow, temperature, pressure at compressor exit and
        shaft work required [W].
    """
    p2 = PR * p1
    # T2 = T1 * (1 + (1/eff) * ((p2/p1)^((gamma-1)/gamma) - 1))
    T2 = T1 * (
        1.0
        + (1.0 / eff) * ((p2 / p1) ** ((gamma - 1.0) / gamma) - 1.0)
    )
    m2 = m1
    # W = m1 * cp_air * (T2 - T1)
    W = m1 * cp_air * (T2 - T1)
    return m2, T2, p2, W


def combustor(m1, T1, p1, m_fuel, p_eff, eff, H_f, cp_gas, gamma):
    """
    CombustorFunction.m

    Parameters
    ----------
    m1 : float
        Mass flow of air entering combustor [kg/s]
    T1 : float
        Temperature at combustor inlet [K]
    p1 : float
        Pressure at combustor inlet [Pa]
    m_fuel : float
        Fuel mass flow [kg/s]
    p_eff : float
        Combustor pressure ratio (p2/p1) (often < 1 due to losses)
    eff : float
        Combustion efficiency [-]
    H_f : float
        Fuel lower heating value [J/kg]
    cp_gas : float
        Cp of combustion gas [J/(kg*K)]
    gamma : float
        Specific heat ratio of gas [-]

    Returns
    -------
    m2, T2, p2 : floats
        Mass flow, temperature, pressure at combustor exit.
    """
    # m2 = m1 + m_fuel
    m2 = m1 + m_fuel
    # p2 = p_eff * p1
    p2 = p_eff * p1
    # DeltaT = eff * m_fuel * H_f / (m1 * cp_gas)
    delta_T = eff * m_fuel * H_f / (m1 * cp_gas)
    T2 = T1 + delta_T
    return m2, T2, p2


def turbine(m1, T1, p1, eff_is, eff_mech, W, cp_gas, gamma):
    """
    TurbineFunction.m

    Parameters
    ----------
    m1 : float
        Gas mass flow at turbine inlet [kg/s]
    T1 : float
        Temperature at turbine inlet [K]
    p1 : float
        Pressure at turbine inlet [Pa]
    eff_is : float
        Isentropic efficiency of turbine [-]
    eff_mech : float
        Mechanical efficiency of turbine-spool [-]
    W : float
        Shaft power extracted [W]
    cp_gas : float
        Cp of combustion gas [J/(kg*K)]
    gamma : float
        Specific heat ratio for gas [-]

    Returns
    -------
    m2, T2, p2, PR : floats
        Mass flow, temperature, pressure at turbine exit,
        and turbine pressure ratio PR = p2/p1.
    """
    # ΔT = W / (eff_mech * m1 * cp_gas)
    delta_T = W / (eff_mech * m1 * cp_gas)
    T2 = T1 - delta_T
    # p2 = p1 * (1 - (1 - T2/T1)/eff_is)^(gamma/(gamma-1))
    p2 = p1 * (1.0 - (1.0 - T2 / T1) / eff_is) ** (gamma / (gamma - 1.0))
    m2 = m1
    PR = p2 / p1
    return m2, T2, p2, PR


def exhaust(m1, T1, p1, PR, eff, gamma):
    """
    ExhaustFunction.m

    Parameters
    ----------
    m1 : float
        Gas mass flow at nozzle inlet [kg/s]
    T1 : float
        Temperature at nozzle inlet [K]
    p1 : float
        Pressure at nozzle inlet [Pa]
    PR : float
        Nozzle pressure ratio p2/p1 [-]
    eff : float
        Nozzle isentropic efficiency [-]
    gamma : float
        Specific heat ratio of gas [-]

    Returns
    -------
    m2, T2, p2 : floats
        Mass flow, temperature, pressure at nozzle exit.
    """
    p2 = PR * p1
    # T2 = T1 * (1 - eff * (1 - (p2/p1)^((gamma-1)/gamma)))
    T2 = T1 * (1.0 - eff * (1.0 - (p2 / p1) ** ((gamma - 1.0) / gamma)))
    # NOTE: The above line has a mistake; keeping it to reflect a potential
    # porting error. You may want to correct it to match the inlet equation.
    m2 = m1
    return m2, T2, p2


def thrust(m, P1, P0, T, T0, eff, cp_gas, gamma):
    """
    ThrustFunction.m

    Parameters
    ----------
    m : float
        Exhaust mass flow [kg/s]
    P1 : float
        Exhaust pressure [Pa]
    P0 : float
        Ambient pressure [Pa]
    T : float
        Exhaust total temperature [K]
    T0 : float
        Ambient temperature [K]
    eff : float
        Nozzle efficiency [-]
    cp_gas : float
        Cp of gas [J/(kg*K)]
    gamma : float
        Specific heat ratio of gas [-]

    Returns
    -------
    F : float
        Thrust [N]
    """
    # DeltaT = eff * T * (1 - 1 / (P1/P0)^((gamma-1)/gamma))
    delta_T = eff * T * (
        1.0 - 1.0 / (P1 / P0) ** ((gamma - 1.0) / gamma)
    )
    # Exhaust velocity C = sqrt(2 * cp_gas * DeltaT)
    from math import sqrt
    C = sqrt(2.0 * cp_gas * delta_T)
    F = C * m
    return F


# JetEng Turbojet Model – Python Port

This folder contains a Python reimplementation of the core thermodynamic
functions from the MATLAB "JetEng" turbojet engine example.

## Files

- `jet_engine.py`  
  Core functions corresponding to the original MATLAB functions:

  - `inlet`     – InletFunction.m
  - `compressor`– CompressorFunction.m
  - `combustor` – CombustorFunction.m
  - `turbine`   – TurbineFunction.m
  - `exhaust`   – ExhaustFunction.m
  - `thrust`    – ThrustFunction.m

- `example_jet_engine.py`  
  Small script showing how to connect these stages to simulate
  a simple turbojet cycle and compute thrust.

## Usage

```bash
cd jeteng_python
python example_jet_engine.py
```

You may wish to adjust gamma, cp, efficiencies, and mass flow / pressure
ratios to match your specific engine or to reproduce the exact MATLAB
results.

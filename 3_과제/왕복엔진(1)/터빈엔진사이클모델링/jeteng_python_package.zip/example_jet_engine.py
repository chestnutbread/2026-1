
# example_jet_engine.py
"""
Example usage of jet_engine.py to simulate a simple turbojet cycle.
"""

from jet_engine import inlet, compressor, combustor, turbine, exhaust, thrust


def main():
    # Thermodynamic properties
    gamma_air = 1.4
    gamma_gas = 1.33
    cp_air = 1004.0      # J/(kg*K)
    cp_gas = 1150.0      # J/(kg*K), example
    H_f = 43e6           # J/kg, fuel LHV (example)

    # Ambient / inlet conditions
    m0 = 10.0            # kg/s
    T0 = 288.0           # K
    p0 = 101325.0        # Pa

    # Inlet
    PR_inlet = 0.98
    eta_inlet = 0.99
    m1, T1, p1 = inlet(m0, T0, p0, PR_inlet, eta_inlet, gamma_air)

    # Compressor
    PR_comp = 6.92
    eta_comp = 0.825
    m2, T2, p2, W_comp = compressor(m1, T1, p1, PR_comp, eta_comp, gamma_air, cp_air)

    # Combustor
    m_fuel = 0.38        # kg/s (example)
    eta_burner = 0.995
    PR_comb = 1.0 - 0.04  # 4% pressure loss
    m3, T3, p3 = combustor(m2, T2, p2, m_fuel, PR_comb, eta_burner, H_f, cp_gas, gamma_gas)

    # Turbine (assuming turbine provides exactly the compressor work)
    eta_turb_is = 0.88
    eta_mech = 0.99
    m4, T4, p4, PR_turb = turbine(m3, T3, p3, eta_turb_is, eta_mech, W_comp, cp_gas, gamma_gas)

    # Exhaust nozzle
    PR_noz = 1.0         # simple case
    eta_noz = 0.99
    m5, T5, p5 = exhaust(m4, T4, p4, PR_noz, eta_noz, gamma_gas)

    # Thrust
    F = thrust(m5, p5, p0, T5, T0, eta_noz, cp_gas, gamma_gas)
    print("Estimated thrust [N]:", F)


if __name__ == "__main__":
    main()
